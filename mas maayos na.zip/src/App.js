import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Home from './components/Home';
import About from './about/About';
import Features from './features/Features';
import Download from './download/Download';
import Events from './events/Events';
import Contact from './contact/Contact';
import Recycle from './recycle/Recycle';
import Rewards from './rewards/Rewards';
import Profile from './profile/Profile';
import Login from './components/Login';
import Signup from './components/Signup';
import { AuthProvider } from './components/AuthContext';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Header />
          <Routes>
            <Route path="/" element={
              <>
                <div id="home">
                  <Home />
                </div>
                <div id="about">
                  <About />
                </div>
                <div id="features">
                  <Features />
                </div>
                <div id="download">
                  <Download />
                </div>
                <div id="events">
                  <Events />
                </div>
                <div id="contact">
                  <Contact />
                </div>
              </>
            } />
            <Route path="/signup" element={<Signup />} />
            <Route path="/recycle" element={<Recycle />} />
            <Route path="/rewards" element={<Rewards />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/login" element={<Login />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
