import React from 'react';
import './About.css';
import About1 from '../images/About1.jpg';

const About = () => {
  return (
    <section id="about" className="about-section">
      <div className="about-container">
        <div className="about-text">
          <h2>ABOUT</h2>

          <h1>Vision</h1>
          <p>
            We envision Muntinlupa City as a well-planned, clean and green, premier city,
            with its peace-loving, hardworking, and dedicated people, enjoying a clean,
            orderly, and healthful way of living.
          </p>

          <h1>Mission</h1>
          <p>
            Towards this vision, we shall be working for the involvement of barangays,
            business sectors, students, non-government organizations, government
            organizations, and other community organizations for the adoption,
            management, and implementation of an ecological solid waste management system,
            to safely and effectively handle solid waste with the least harmful impacts on
            human health and the environment. Likewise, strict enforcement of environmental
            laws will be effected in coordination with other environmental agencies to attain this mission.
          </p>
        </div>
        <div className="about-image">
          <img src={About1} alt="Recycloop Team" />
        </div>
      </div>
    </section>
  );
};

export default About;
