import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../../src/recyclooplogo.png';
import './Header.css';
import { useAuth } from './AuthContext';

function Header() {
  const { isLoggedIn, logout } = useAuth();
  const navigate = useNavigate();

  const scrollToSection = (id, event) => {
    event.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header>
      <div className="header-content">
        <div className="logo">
          <img src={logo} alt="Recycloop Logo" className="logo-image" />
          <span className="brand-name">RECYCLOOP</span>
        </div>
        <nav>
          <ul>
            {isLoggedIn ? (
              <>
                <li><Link to="/">HOME</Link></li>
                <li><Link to="/" onClick={(e) => scrollToSection('about', e)}>ABOUT</Link></li>
                <li><Link to="/" onClick={(e) => scrollToSection('features', e)}>FEATURES</Link></li>
                <li><Link to="/" onClick={(e) => scrollToSection('events', e)}>EVENTS</Link></li>
                <li><Link to="/" onClick={(e) => scrollToSection('contact', e)}>CONTACT</Link></li>
                <li><Link to="/recycle">RECYCLE</Link></li>
                <li><Link to="/rewards">REWARDS</Link></li>
                <li><Link to="/profile">PROFILE</Link></li>
                <li><button className="logout-button" onClick={handleLogout}>LOGOUT</button></li>
              </>
            ) : (
              <>
                <li><a href="#home" onClick={(e) => scrollToSection('home', e)}>HOME</a></li>
                <li><a href="#about" onClick={(e) => scrollToSection('about', e)}>ABOUT</a></li>
                <li><a href="#features" onClick={(e) => scrollToSection('features', e)}>FEATURES</a></li>
                <li><a href="#events" onClick={(e) => scrollToSection('events', e)}>EVENTS</a></li>
                <li><a href="#contact" onClick={(e) => scrollToSection('contact', e)}>CONTACT</a></li>
                <li>
                  <button className="login-button" onClick={() => navigate('/login')}>LOGIN</button>
                </li>
              </>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default Header;
