// Home.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Home1 from '../images/Home1.jpg';
import './Home.css';

const Home = () => {
  const navigate = useNavigate();

  const handleSignup = () => {
    navigate('/signup');
  };

  return (
    <div className="container" id="home"> 
      <div className="image">
        <img src={Home1} alt="Recycling Center" />
        <div className="overlay">
          <div className="header">
            <h1>RECYCLOOP</h1>
            <p>Turning trash into treasure, one loop at a time.</p>
            <button onClick={handleSignup}>SIGNUP</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
