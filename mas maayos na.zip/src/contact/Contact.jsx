import React from 'react';
import './Contact.css';

const Contact = () => {
  return (
    <div className="contact-container" id="contact"> 
      <h2>CONTACT</h2>
      <p><strong>Address:</strong> 93M2+RH6, Arandia St, Tunasan, Muntinlupa, Metro Manila</p>
      <p><strong>Email:</strong> muntinlupacityesc@gmail.com</p>
      <p><strong>Telephone No:</strong> 8 861-1866 / 8 862-0352</p>
      <hr />
      <footer>©2024 by RECYCLOOP. All rights reserved.</footer>
    </div>
  );
}

export default Contact;
