import React from 'react';
import './Download.css';

function Download() {
  return (
    <section> 
      <h2>Download Our Mobile App</h2>
      <p>
        Experience the convenience of managing your waste disposal and recycling efforts right from your phone.
      </p>
      <div className="app-buttons">
        <a href="https://play.google.com/store" className="app-button google-play">Google Play</a>
        <a href="https://www.apple.com/app-store/" className="app-button app-store">App Store</a>
      </div>
    </section>
  );
}

export default Download;
