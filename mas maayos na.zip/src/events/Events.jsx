import React from 'react';
import './Events.css';

const events = [
  {
    date: 'JULY 29',
    title: 'Barangay Cleanup Drive',
    location: 'Barangay Cupang',
    time: '08:30 am - 11:30 am',
  },
  {
    date: 'AUGUST 5',
    title: 'Community Health Seminar',
    location: 'Barangay Sucat',
    time: '08:30 am - 10:00 am',
  },
  {
    date: 'AUGUST 12',
    title: 'Recycling Workshop',
    location: 'Barangay Sucat',
    time: '01:00 pm - 4:00 pm',
  },
  {
    date: 'AUGUST 19',
    title: 'Tree Planting Activity',
    location: 'Barangay Cupang',
    time: '07:30 am - 12:00 pm',
  },
];

const Events = () => {
  return (
    <div className="events-container" id="events"> {/* Added id="events" here */}
      <div className="events-header">
        <h2>EVENTS</h2>
        <p>Join events to earn eco-points to claim in your account!</p>
      </div>
      <div className="events-grid">
        {events.map((event, index) => (
          <div key={index} className="event-card">
            <div className="event-date">{event.date}</div>
            <div className="event-title">{event.title}</div>
            <div className="event-location">Location: {event.location}</div>
            <div className="event-time">Time: {event.time}</div>
            <button className="register-button">REGISTER NOW</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Events;
