// src/components/Features.jsx
import React from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // Import the carousel styles
import { Carousel } from 'react-responsive-carousel';
import Carousel1 from '../images/Carousel1.jpg';
import Carousel2 from '../images/Carousel2.jpg';
import Carousel3 from '../images/Carousel3.jpg';
import './Features.css';

const Features = () => {
  return (
    <div id="features" className="features-container">
      <Carousel 
        showArrows={true} 
        autoPlay={true} 
        infiniteLoop={true}
        showThumbs={false}
        showStatus={false}
      >
        <div>
          <img src={Carousel1} alt="Feature 1" />
          
        </div>
        <div>
          <img src={Carousel2} alt="Feature 2" />
          
        </div>
        <div>
          <img src={Carousel3} alt="Feature 3" />
          
        </div>
      </Carousel>
    </div>
  );
}

export default Features;
