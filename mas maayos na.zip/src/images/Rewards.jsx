import React, { useState } from 'react';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import Reward1 from '../images/Reward1.jpg';
import Reward2 from '../images/Reward2.jpg';
import Reward3 from '../images/Reward3.jpg';
import Reward4 from '../images/Reward4.jpg';
import Reward5 from '../images/Reward5.jpg';
import Reward6 from '../images/Reward6.jpg';
import './Rewards.css';

const rewardsData = [
  { id: 1, title: 'Rice', points: 10, image: Reward1, description: '1 kilo of rice.' },
  { id: 2, title: 'Soil Fertilizer', points: 25, image: Reward2, description: 'This is from bayanan a soil fertilizer that is made up from vegetables.' },
  { id: 3, title: 'Random Canned Goods', points: 35, image: Reward3, description: 'Random canned goods.' },
  { id: 4, title: 'Ketchup Bottle', points: 40, image: Reward4, description: 'UFC Banana Ketchup.' },
  { id: 5, title: 'Soap Detergent', points: 50, image: Reward5, description: 'Random soap detergent.' },
  { id: 6, title: 'Random Kitchen Essentials', points: 60, image: Reward6, description: 'Random kitchen essentials that can be oil, suka, toyo and patis.' },
];

const Rewards = () => {
  const [selectedReward, setSelectedReward] = useState(rewardsData[0]);

  const handleImageClick = (reward) => {
    setSelectedReward(reward);
  };

  return (
    <Container>
      <Row className="justify-content-center my-4">
        <Col md={12} className="text-center">
          <h1 className="rewards-title">REWARDS</h1>
          <h5 className="eco-points">Your Eco-Points: 0</h5>
        </Col>
      </Row>
      <Row className="justify-content-center my-5">
        <Col md={6} className="text-center reward-details">
          <h3>{selectedReward.title}</h3>
          <p className="description">{selectedReward.description}</p>
          <Button variant="primary" className="choose-button">CHOOSE!</Button>
        </Col>
        <Col md={6} className="text-center">
          <img
            src={selectedReward.image}
            alt="Selected Reward"
            className="img-fluid selected-image"
          />
        </Col>
      </Row>
      <Row className="text-center reward-gallery">
        {rewardsData.map(reward => (
          <Col md={4} lg={2} className="mb-4" key={reward.id}>
            <Card onClick={() => handleImageClick(reward)} className="reward-card" style={{ cursor: 'pointer' }}>
              <Card.Img variant="top" src={reward.image} alt={`Reward ${reward.id}`} className="reward-image"/>
              <Card.Body>
                <Card.Title>{reward.title}</Card.Title>
                <Card.Text>{`${reward.points} points`}</Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default Rewards;
