import React from 'react';
import Profile1 from '../images/Profile.jpg';
import './Profile.css';

const Profile = () => {
  return (
    <div className="profile-container">
      <div className="profile-card">
        <div className="profile-picture">
        <img src={Profile1} alt="Feature 1" />
        </div>
        <div className="profile-details">
          <h2>User Profile</h2>
          <form className="profile-form">
            <div className="form-group">
              <label htmlFor="firstName">First Name:</label>
              <input type="text" id="firstName" name="firstName" defaultValue="John" disabled />
            </div>
            <div className="form-group">
              <label htmlFor="lastName">Last Name:</label>
              <input type="text" id="lastName" name="lastName" defaultValue="Doe" disabled />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input type="email" id="email" name="email" defaultValue="john.doe@example.com" disabled />
            </div>
            <div className="form-group">
              <label htmlFor="birthday">Birthday:</label>
              <input type="date" id="birthday" name="birthday" defaultValue="1990-01-01" disabled />
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Profile;
