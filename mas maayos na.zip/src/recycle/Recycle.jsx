import React, { useState } from 'react';
import './Recycle.css'; // Import the CSS file

const Recycle = () => {
  const [formData, setFormData] = useState({
    recyclableItems: '',
    piecesKgs: '',
    itemsWeight: '',
    date: ''
  });

  const [submittedData, setSubmittedData] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmittedData([...submittedData, formData]);
    setFormData({
      recyclableItems: '',
      piecesKgs: '',
      itemsWeight: '',
      date: ''
    });
  };

  return (
    <div className="recycle-form">
      <h2>Recycle Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="recyclableItems">Recyclable Items:</label>
          <input
            type="text"
            id="recyclableItems"
            name="recyclableItems"
            value={formData.recyclableItems}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="piecesKgs">Pieces</label>
          <input
            type="number"
            id="piecesKgs"
            name="piecesKgs"
            value={formData.piecesKgs}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="itemsWeight">Items Weight (Kgs):</label>
          <input
            type="number"
            id="itemsWeight"
            name="itemsWeight"
            value={formData.itemsWeight}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="date">Date:</label>
          <input
            type="date"
            id="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" id="submitRecycleButton">Submit</button>
      </form>
      
      <div className="submitted-data">
        <h3>Submitted Data</h3>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Recyclable Items</th>
              <th>Pieces</th>
              <th>Items Weight (Kgs)</th>
            </tr>
          </thead>
          <tbody>
            {submittedData.map((data, index) => (
              <tr key={index}>
                <td>{data.date}</td>
                <td>{data.recyclableItems}</td>
                <td>{data.piecesKgs}</td>
                <td>{data.itemsWeight}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Recycle;
