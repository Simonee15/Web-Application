import React, { useState } from 'react';
import './Rewards.css';
import Reward1 from '../images/Reward1.jpg';
import Reward2 from '../images/Reward2.jpg';
import Reward3 from '../images/Reward3.jpg';
import Reward4 from '../images/Reward4.jpg';
import Reward5 from '../images/Reward5.jpg';

const rewards = [
  { image: Reward1, label: 'Joy Dishwashing Soap', points: 100 },
  { image: Reward2, label: 'Toyo Datu Puti', points: 40 },
  { image: Reward3, label: 'Suka Datu Puti', points: 40 },
  { image: Reward4, label: 'Corned Beef', points: 175 },
  { image: Reward5, label: 'Ariel Soap Powder', points: 15 },
];

const Rewards = () => {
  const [myPoints,] = useState(50); // Example points
  const [selectedReward, setSelectedReward] = useState(null);

  const handleRewardClick = (reward) => {
    setSelectedReward(reward);
  };

  return (
    <div className="rewards-page">
      <div className="my-points">
        <h2>My Points: {myPoints}</h2>
      </div>
      {selectedReward && (
        <div className="reward-preview">
          <img src={selectedReward.image} alt={selectedReward.label} className="reward-preview-image" />
          <div className="reward-preview-details">
            <h3>{selectedReward.label}</h3>
            <p>{selectedReward.description}</p>
            <p>{selectedReward.points} Points</p>
            <button
              id="claim-reward-button" // Added ID here
              className="choose-reward-button"
              onClick={() => alert(`You have chosen ${selectedReward.label}.`)}
              disabled={myPoints < selectedReward.points}
            >
              {myPoints >= selectedReward.points ? 'Claim Reward' : 'Insufficient Points'}
            </button>
          </div>
        </div>
      )}
      <div className="rewards-container">
        {rewards.map((reward, index) => (
          <div key={index} className="reward-item" onClick={() => handleRewardClick(reward)}>
            <img src={reward.image} alt={reward.label} className="reward-image" />
            <div className="reward-details">
              <h3 className="reward-label">{reward.label}</h3>
              <p className="reward-points">{reward.points} Points</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Rewards;
